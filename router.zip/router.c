#include "skel.h"

struct route_table *rtable;
int rtable_size;
int arp_table_len;
struct arp_entry *arp_table;

int parsare_rtable(struct route_table *rtable){
	FILE *f;
	char* p = malloc(100*sizeof(char));
	f = fopen("rtable.txt", "r");
	if (f==NULL){
		perror("Eroare la deschiderea fisierului");
	}
	int i=0;
	int a;
	while(!feof(f)){
		fscanf(f,"%s",p);
		//prelucrare prefix
		rtable[i].prefix = inet_addr(p);
		if (!feof(f))
			fscanf(f,"%s",p);
		//prelucrare next_hop
		rtable[i].next_hop = inet_addr(p);
		if (!feof(f))
			fscanf(f,"%s",p);
		//prelucrare mask
		rtable[i].mask = inet_addr(p);
		if (!feof(f))
			fscanf(f,"%s",p);
		//prelucrare interface
		a = atoi(p);
		rtable[i].interface = a;
		i++;
	}
	fclose(f);
	return i;
}

struct route_table *get_best_route(__u32 dest_ip) {
	__u32 max = 0;
	int index = 0;
	for (int i=0 ; i<rtable_size ; i++){
		int aux = dest_ip & rtable[i].mask;
		if (aux == rtable[i].prefix){
			if (rtable[i].mask > max){
				index = i;
				max = rtable[i].mask;
			}
		}
	}
	if (index==0)
		return NULL;
	else
		return &rtable[index];
}

struct arp_entry *get_arp_entry(__u32 ip) {
    for (int i=0 ; i<arp_table_len ; i++){
    	if (arp_table[i].ip == ip)
    		return &arp_table[i];
    }
    return NULL;
}

int main(int argc, char *argv[])
{
	packet m;
	int rc;

	init();
	char *ip_meu = malloc(100*sizeof(char));
	uint32_t ip_meu_ipv4;
	rtable = malloc(90000*sizeof(struct route_table));
	rtable_size = parsare_rtable(rtable);
	arp_table = malloc(sizeof(struct arp_entry) * 100);
	parse_arp_table();

	while (1) {
		rc = get_packet(&m);
		DIE(rc < 0, "get_message");

		/* Students will write code here */
		struct ether_header *eth_header = (struct ether_header*)m.payload;
		struct iphdr *ip_hdr = (struct iphdr*)(m.payload + sizeof(struct ether_header));
		struct icmphdr *icmp_hdr = (struct icmphdr *)(m.payload + sizeof(struct iphdr) + sizeof(struct ether_header));

		ip_meu = get_interface_ip(m.interface);
		ip_meu_ipv4 = inet_addr(ip_meu);

		//Daca un pachet este destinat routerului
		if (ip_meu_ipv4 == ip_hdr->daddr){
			//Daca este un pachet de tip ECHO request
			if (icmp_hdr->type == ICMP_ECHO){
				//Trimit ECHO REPLY
				icmp_hdr->type = ICMP_ECHOREPLY;
				send_packet(m.interface,&m);
				continue;
			}
		}
		else{
			//Daca checksum-ul e gresit, arunc pachetul
		if (ip_checksum(ip_hdr, sizeof(struct iphdr)) != 0){
			printf("Checksum gresit !");
			//Arunc pachetul
			continue;
		}
		// Daca e un pachet cu TTL <= 1
		if (ip_hdr->ttl <= 1){
			puts("EROARE!!! TTL nu e ok");
			printf("%d\n", ip_hdr->ttl);
			//Trimit mesaj TIME_EXCEEDED sursei
			packet pkt;
			//Folosesc un pachet nou, pentru ca updatand pachetul existent nu am reusit :(
			init_packet(&pkt);

			pkt.len = sizeof(struct ether_header) + sizeof(struct iphdr)+ sizeof(struct icmphdr);
			struct ether_header *eth_hdr2 = (struct ether_header *)pkt.payload;

			struct iphdr *ip_hdr_aux = (struct iphdr*)(pkt.payload + sizeof(struct ether_header));
			struct icmphdr *icmp_hdr_aux = (struct icmphdr *)(pkt.payload + sizeof(struct iphdr) + sizeof(struct ether_header));

			eth_hdr2->ether_type = eth_header->ether_type;
			memcpy(eth_hdr2->ether_dhost,eth_header->ether_shost,10);
			get_interface_mac(m.interface,eth_hdr2->ether_shost);
			
			icmp_hdr_aux->type = ICMP_TIME_EXCEEDED;
			ip_hdr_aux->ttl = 64;
			ip_hdr_aux->protocol = IPPROTO_ICMP;
			ip_hdr_aux->id = getpid();
			ip_hdr_aux->daddr = ip_hdr->saddr;
			ip_hdr_aux->tot_len = htons(sizeof(struct iphdr) + sizeof(struct icmphdr));
			ip_hdr_aux->saddr = inet_addr(get_interface_ip(m.interface));
			ip_hdr_aux->check = 0;
		 	ip_hdr_aux->check = ip_checksum(ip_hdr, sizeof(struct iphdr));

			icmp_hdr_aux->checksum = 0;
			icmp_hdr_aux->checksum = ip_checksum(icmp_hdr, sizeof(struct icmphdr));
			pkt.interface = m.interface;
			send_packet(pkt.interface,&pkt);
			//Arunc pachetul
			continue;
		}

		// Decrementez TTL, updatez checksum-ul
		ip_hdr->ttl--;
		ip_hdr->check=0;
		ip_hdr->check = ip_checksum(ip_hdr , sizeof(struct iphdr));

		//Gasesc ruta cea mai buna
		struct route_table *rt = get_best_route(ip_hdr->daddr);
		if (rt == NULL){
			puts("Nu exista cea mai buna ruta");
			//Daca nu se gaseste, trimit mesaj sursei

			packet pkt;
			init_packet(&pkt);

			pkt.len = sizeof(struct ether_header) + sizeof(struct iphdr)+ sizeof(struct icmphdr);
			struct ether_header *eth_hdr2 = (struct ether_header *)pkt.payload;

			struct iphdr *ip_hdr_aux = (struct iphdr*)(pkt.payload + sizeof(struct ether_header));
			struct icmphdr *icmp_hdr_aux = (struct icmphdr *)(pkt.payload + sizeof(struct iphdr) + sizeof(struct ether_header));
 
			eth_hdr2->ether_type = eth_header->ether_type;
			memcpy(eth_hdr2->ether_dhost,eth_header->ether_shost,10);
			get_interface_mac(m.interface,eth_hdr2->ether_shost);
			
			icmp_hdr_aux->type = ICMP_DEST_UNREACH;
			ip_hdr_aux->ttl = 64;
			ip_hdr_aux->protocol = IPPROTO_ICMP;
			ip_hdr_aux->id = getpid();
			ip_hdr_aux->daddr = ip_hdr->saddr;
			ip_hdr_aux->tot_len = htons(sizeof(struct iphdr) + sizeof(struct icmphdr));
			ip_hdr_aux->saddr = inet_addr(get_interface_ip(m.interface));
			ip_hdr_aux->check = 0;
		 	ip_hdr_aux->check = ip_checksum(ip_hdr, sizeof(struct iphdr));

			icmp_hdr_aux->checksum = 0;
			icmp_hdr_aux->checksum = ip_checksum(icmp_hdr, sizeof(struct icmphdr));
			pkt.interface = m.interface;
			send_packet(m.interface,&pkt);

			//Arunc pachetul
			continue;
		}

		struct arp_entry *arp = get_arp_entry(rt->next_hop);
		if (arp == NULL)
		{
			puts("Eroare get_arp_entry, nu avem adresa MAC");
			continue;
		}

		memcpy(eth_header->ether_shost,eth_header->ether_dhost,sizeof(eth_header->ether_dhost));
		memcpy(eth_header->ether_dhost,arp->mac,sizeof(arp->mac));

		send_packet(rt->interface, &m);
	}
}
}
